'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
const SCHOOL_TYPE = {
  'ELEMENTARY': 2, //초등
  'MIDDLE': 3, //중등
  'HIGH': 4 //고등
};

exports.default = SCHOOL_TYPE;